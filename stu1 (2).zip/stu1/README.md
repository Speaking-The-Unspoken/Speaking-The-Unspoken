# STU1

A Pen created on CodePen.

Original URL: [https://codepen.io/Dhruv-Manshani/pen/raOzdNq](https://codepen.io/Dhruv-Manshani/pen/raOzdNq).

